import copy
import re

import pandas as pd
from tqdm import tqdm
from model_access import *
from openai import OpenAI

OPENAI_API_KEY = 'your key'
client = OpenAI(api_key=OPENAI_API_KEY, base_url=BASE_URL)

def judge(dataset):
    for info in ['rel','inf']:
        for file_tail in ['raw','total']:
            file = f'experiment/check_data/RQ2/checked/{dataset}_{info}_ran100_{file_tail}.csv'
            data = pd.read_csv(file, header=None, encoding='ISO-8859-1').values.tolist()
            new_data = []
            for i in tqdm(range(len(data))):
                man1 = data[i][4]
                man2 = data[i][5]
                manual = data[i][6]
                gpt1 = data[i][7]
                gpt2 = data[i][9]
                if man1 == man2 :
                    if man2 == 2:
                        copy_data = copy.deepcopy(data[i])
                        copy_data[-1] = 'C'
                    else:
                        copy_data = copy.deepcopy(data[i])
                        copy_data[-1] = gpt2
                else:
                    if gpt1 == gpt2:
                        copy_data = copy.deepcopy(data[i])
                        copy_data[-1] = gpt2
                    else:
                        if gpt2 != 'C':
                            if manual == 1:
                                copy_data = copy.deepcopy(data[i])
                                copy_data[-1] = gpt2
                            elif manual == 2:
                                copy_data = copy.deepcopy(data[i])
                                copy_data[-1] = 'C'
                        else:
                            if manual == 1:
                                copy_data = copy.deepcopy(data[i])
                                copy_data[-1] = gpt2
                            elif manual == 2:
                                copy_data = copy.deepcopy(data[i])
                                copy_data[-1] = 'C'
                new_data.append(copy_data)
            pd_data = pd.DataFrame(new_data)
            pd_data.to_csv(file, sep=',', header=None, index=None)


def main(dataset):
    for info in ['rel','inf']:
        for file_tail in ['raw','total']:
            file = f'experiment/check_data/RQ2/checked/{dataset}_{info}_ran100_{file_tail}.csv'
            data = pd.read_csv(file, header=None,encoding='ISO-8859-1').values.tolist()
            new_data = []
            for i in tqdm(range(len(data))):
                # assert len(data[i]) == 7
                q = data[i][3]
                c = data[i][1]
                if info == 'rel':
                    a = data[i][2].split(',')[1]
                elif info == 'inf':
                    a = data[i][2]
                prompt = f'''
                You are given a background passage, a generated question based on it, and a target (expected) answer.

The question was generated under specific instructions and constraints, including:
- It must be answerable solely based on the background passage.
- It must not include or imply the answer (no answer leakage).
- It must not introduce facts or knowledge not present in the background.
- It must match the provided target answer if the background supports it.
- It must be structurally complete, clear, and well-formed.

Your task is to check whether the question violates any of the following types of fidelity:

---

Type A — **Content Faithfulness Violation**  
Label: `A`  
Occurs when the question:
- Introduces facts, entities, or relationships not present in the background.
- Misrepresents the background (e.g., incorrect causality, contradiction).
- Cannot be answered based on the background passage.

---

Type B — **Instructional Faithfulness Violation**  
Label: `B`  
Occurs when the question:
- Violates generation constraints such as:
  - Answer leakage (the answer is revealed or implied).
  - Asking about information outside the scope of the background.
  - Format errors (incomplete question, unclear focus).
  - The question is answerable from the background, but the target answer does **not** match the correct answer implied by the background.

---

Type C — **No Violation**  
Label: `C`  
The question:
- Is fully supported by the background.
- Is aligned with the expected answer.
- Follows all format and instruction rules.

---

Please output one of the following labels: A / B / C  
Also briefly explain your reasoning.

Format:
---
Background:  
{c}

Question:  
{q}

Target Answer:  
{a}

Label:  
A / B / C

Explanation:  
[Your brief reasoning]

Please return your answer in the following JSON format:
{{  
  "label": "A",  
  "explanation": "..."  
}}

                '''
                result = connect_gpt_prompt_cov(prompt,client)
                # label = re.findall()
                match = re.search(r'\{.*?\}', result, re.DOTALL)
                if match:
                    json_str = match.group(0)
                    try:
                        json_data = json.loads(json_str)
                        label = json_data["label"]
                        explanation = json_data["explanation"]
                    except json.JSONDecodeError as e:
                        print("JSON 解析失败:", e)
                else:
                    print("没有找到 JSON 内容")
                copy_data = copy.deepcopy(data[i])
                copy_data.extend([label,explanation])
                new_data.append(copy_data)
                a = 1
            pd_data = pd.DataFrame(new_data)
            pd_data.to_csv(file, sep=',', header=None, index=None)

def quchong(dataset):
    file = f'experiment/qaasker/qaasker_{dataset}_after_con.csv'
    data = pd.read_csv(file,header=None).values.tolist()


if __name__ == '__main__':
    f()
    # for dataset in ['squad2','nat','boolq']:
        # main(dataset)
        # judge(dataset)
